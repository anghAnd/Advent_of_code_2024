#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i=-1,m=-1,j,s=0,x=0,z=1; //z numara cati de 0 sunt
    char A[1000][1000],c,line[1000],cautare;

    FILE *file;
    file=fopen("input.txt","r");

    if(file==NULL)
    {
        printf("Eroare la deschiderea fisierului.");
        return 1;
    }

    while(fgets(line,sizeof(line),file))
    {   i++;
        n=strlen(line);
        if (line[n - 1] == '\n')  // Eliminã newline-ul
            line[n - 1] = '\0';
        for(j=0;j<n;j++)//numarul de coloane + parcurgerea liniei curente
            A[i][j]=line[j]-'0';
        m++;//numarul liniei
    }

   // i=-1;
   // for(j=-1;j<=n;j++)
   //     A[i][j]=-1;
   // i=m+1;
   // for(j=-1;j<=n;j++)
   //     A[i][j]=-1;
   // j=-1;
   //for(i=-1;i<=m+1;i++)
   //     A[i][j]=-1;
   // j=n;
   // for(i=-1;i<=m+1;i++)
   //     A[i][j]=-1;

    for(i=0;i<=m;i++)
    {
       for(j=0;j<n;j++)
         printf("%d ",A[i][j]);
       printf("\n");
    }

    for(i=0;i<=m;i++)
       for(j=0;j<n;j++)
    {  x=0;
       while(A[i][j]!=0)
       {
           i++;
           j++;
       }

        if(A[i][j]==0)
              {
                cautare=1;
                if(A[i-1][j]==cautare && i-1>=0)
                  while(cautare<9 && i>=0 && i<=m && j>=0 && j<n)
                    {while(A[i-1][j]==cautare && i-1>=0)
                       {
                        i--;
                        cautare++;
                       }
                       if(cautare-1==9)
                        x++;
                     while(A[i+1][j]==cautare && i+1<=m)
                        {
                         i++;
                         cautare++;
                        }
                       if(cautare-1==9)
                        x++;
                     while(A[i][j-1]==cautare && j-1>=0)
                        {
                         j--;
                         cautare++;
                        }
                        if(cautare-1==9)
                        x++;
                    while(A[i][j+1]==cautare && j+1<n)
                        {
                         j++;
                         cautare++;
                        }
                       if(cautare-1==9)
                        x++;
                        i++;
                        j++;
                    }
                 if(A[i+1][j]==cautare && i+1<=m)
                    while(cautare<9 && i>=0 && i<=m && j>=0 && j<n)
                    {while(A[i-1][j]==cautare && i-1>=0)
                       {
                         i--;
                        cautare++;
                       }
                       if(cautare-1==9)
                            x++;
                     while(A[i+1][j]==cautare && i+1<=m)
                        {
                         i++;
                         cautare++;
                        }
                       if(cautare-1==9)
                        x++;
                     while(A[i][j-1]==cautare && j-1>=0)
                        {
                         j--;
                         cautare++;
                        }
                        if(cautare-1==9)
                        x++;
                    while(A[i][j+1]==cautare && j+1<n)
                        {
                         j++;
                         cautare++;
                        }
                       if(cautare-1==9)
                        x++;
                    }
                if(A[i][j-1]==cautare && j-1>=0)
                    while(cautare<9 && i>=0 && i<=m && j>=0 && j<n)
                    {while(A[i-1][j]==cautare && i-1>=0)
                       {
                        i--;
                        cautare++;
                     }
                       if(cautare-1==9)
                        x++;
                     while(A[i+1][j]==cautare && i+1<=m)
                        {
                         i++;
                         cautare++;
                        }
                       if(cautare-1==9)
                        x++;
                     while(A[i][j-1]==cautare && j-1>=0)
                        {
                         j--;
                         cautare++;
                        }
                        if(cautare-1==9)
                        x++;
                    while(A[i][j+1]==cautare && j+1<n)
                        {
                         j++;
                         cautare++;
                        }
                       if(cautare-1==9)
                        x++;
                    }
                if(A[i][j+1]==cautare && j+1<n)
                    while(cautare<9 && i>=0 && i<=m && j>=0 && j<n)
                    {while(A[i-1][j]==cautare && i-1>=0)
                       {
                        i--;
                        cautare++;
                       }
                       if(cautare-1==9)
                        x++;
                     while(A[i+1][j]==cautare && i+1<=m)
                        {
                         i++;
                         cautare++;
                        }
                       if(cautare-1==9)
                        x++;
                     while(A[i][j-1]==cautare && j-1>=0)
                        {
                         j--;
                         cautare++;
                        }
                        if(cautare-1==9)
                        x++;
                    while(A[i][j+1]==cautare && j+1<n)
                       {
                         j++;
                         cautare++;
                        }
                       if(cautare-1==9)
                        x++;
                    }
               i++;j++;
              }

          printf("Pentru %d '0' sunt %d drumuri.\n",z,x);
          s=s+x;
          z++;
          i++;
          j++;

    }
    printf("%d",s);

    fclose(file);
    return 0;
}
