#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    long int c1,c2,i=0,aux,j,V[10000][2],k,s,n,t,ok,nr,X=0;
    char c,line[10000],*p;
    long int A[10000];
   FILE *file;
   file=fopen("er.txt","r");


   if(file==NULL)
    {
        printf("Eroare la deschiderea fisierului.");
        return 1;
    }

   while(fscanf(file,"%d %c %d",&c1,&c,&c2)==3)
    {   V[i][0]=c1;
        V[i][1]=c2;
        i++;
    }
    i--;
    for(j=0;j<i;j++)
     printf("%d %d\n",V[j][0],V[j][1]);
    printf("\n");
    //printf("%d,%d",c1,c2);
    A[0]=c1;
    A[1]=c2;
    fgets(line,sizeof(line),file);
    n=strlen(line);
    //printf("%s",line);
    //printf("%d\n",n);
    k=2;
    s=1;
    while(s<n-2)
    {       c1=line[s]-'0';
            c2=line[s+1]-'0';
            int num=c1*10+c2;
            A[k]=num;
        s=s+3;k++;
    }
    for(int j=0;j<k-1;j++)
        {    nr=0;
             ok=1;
            for(int t=0;t<i;t++)
            {
                if(A[j]==V[t][0])
                {
                    for(int j1=j+1;j1<k;j1++)
                    {
                        if(A[j1]==V[t][1])
                            nr++;

                    }
                }
            }
            if(nr==k-(j+1) )
                ok=1;
            else {ok=0;
                  break;}
        }

    if(ok==1)
        {for(j=0;j<k;j++)
            printf("%d ",A[j]);
         printf("\n");
         printf("Elementul din mijloc este: %d\n", A[(k-1)/2]);
         X=X+A[(k-1)/2];
        }
       // else printf("NU");



    while(fgets(line,sizeof(line),file))
    {   // printf("\n");
        //printf("%s ",line);
        n=strlen(line);
        k=0;
        s=0;
        while(s<n-2)
        {   c1=line[s]-'0'; //iau caracter cu caracter
            c2=line[s+1]-'0';
            A[k]=c1*10+c2; //formez fiecare elemnt al vectorului
            s=s+3;k++; //cresc cu 3 prntru a trece de cele 2 cifre pe care le-am adaugat deja unui element dar si de spatiu
        }
       // printf("\n");
        for(int j=0;j<k-1;j++) //parcurg vectorul
           { nr=0;
             ok=1;
            for(int t=0;t<i;t++) //parcurg matricea
            {
                if(A[j]==V[t][0]) //daca primul element al matricei este egal cu elementul actual din vector
                {
                    for(int j1=j+1;j1<k;j1++) //verific daca urmatoarele elemente ce preced elementul din vector pe care ma aflu corespund cu elemente de pe colana a doua a matricei unde se gaseste pe primacolana elementul anterior din vector
                    {
                        if(A[j1]==V[t][1])
                            nr++; //numar sa vad daca toate corespund regulilor
                    }
                }
            }
            if(nr==k-(j+1) ) //daca se toate elementele se gasesc in matrice ca fiind urmasele elementului pentru care verificam
                ok=1;
            else {ok=0;
                  break;}
        }

        if(ok==1)
          {for(j=0;j<k;j++)
              printf("%d ",A[j]);
           printf("\n");
           printf("Elementul din mijloc este: %d\n", A[(k-1)/2]);
           X=X+A[(k-1)/2];
          }
      else {printf("NU corespunde regulilor: ");
            for(j=0;j<k;j++)
               printf("%d ",A[j]);
            printf("\n");

            //part2

            for(j=0;j<k;j++)
            {
                for(int t=0;t<i;t++)
                    if(A[j]==V[t][0])
                       for(int sr=j+1;sr<k;sr++)

                       {
                             {
                                for(int j1=j+1;j1<k;j1++)
                                    {
                                      if(A[j1]==V[t][1])
                                        nr++;
                                    }
                             }
                       }

           }

      }

    }
   printf("\nSuma totala a elementelor din mijloc este: %d\n",X);
   fclose(file);
    return 0;
}
