#include <stdio.h>
#include <stdlib.h>

int main()
{
    long int n,i=0,nr,j,ts,l,r,x,S=0,h,p=0;
    char line[1000],c,V[1000000],s;

   FILE *file;
   file=fopen("r.txt","r");


   if(file==NULL)
    {
        printf("Eroare la deschiderea fisierului.");
        return 1;
    }


    memset(V,0,sizeof(V));
     s='0'; x=0;
   while((c=fgetc(file))!=EOF)
    {
        if(c!='\n')
        {printf("%c",c);
         nr=c-'0';
         while(nr!=0 && i<100000)
         {
             V[i]=s;
             i++;
             nr--;
         }
        }// else if(c=='\n')
         //       {
         //           continue;
         //       }
        if((c=fgetc(file))!=EOF)
        {
           printf("%c",c);
           nr=c-'0';
           x=x+nr;
           while(nr!=0 && i<1000000)
            {
            V[i]='.';
            i++;
            nr--;
            }

        }
        if(s=='9')
            s='0';
        else {
            ts=s-'0'+1;
            s=ts+'0';
        }


    }
    printf("\nNumarul de '.' este: %d\n",x);
    printf("\n");
    for(j=0;j<i;j++)
        printf("%c",V[j]);
     l=i-1;
     j=0;
     while(j<l )//&& x!=0)
     {
         if(V[j]=='.')
         {   if(V[l]!='.')
             {
               V[j]=V[l];
               V[l]='.';
               l--;
               j++;
               //x--;
             }
            else
                {
                     l--;
                }
         }
         else j++;

     }

    printf("\n");
    j=0;
    while(V[j]!='.' && j<i)
        {printf("%c",V[j]);
         j++;
         }
    for(j=0;j<i;j++ )
    {  if(V[j]!='.')
        { h=V[j]-'0';
          p=j*h;
          printf("%d*%d=%d\n",j,h,p);
          S=S+p;
        }

    }


    printf("\n%d",S);
    fclose(file);
    return 0;
}
