#include <stdio.h>
#include <stdlib.h>


int main()
{
    int num1, num2,i=0,j,s=0,a,k,V[9999],A[9999];

	FILE *file;
    file=fopen("input.txt","r");

    if(file==NULL)
    {
        printf_s("Eroare la deschiderea fisierului.\n");
        return 1;
    }

    while (fscanf(file, "%d%d",&num1,&num2)==2)
	{
       printf("%d\t%d\n",num1,num2);
       V[i]=num1;
       A[i]=num2;
       i++;
	}

	for(j=0;j<i-1;j++)
    {
       for(k=j+1;k<i;k++)
       {
           if(V[j]>V[k])
           {
               a=V[j];
               V[j]=V[k];
               V[k]=a;
           }

       }
    }

    for(j=0;j<i-1;j++)
    {
       for(k=j+1;k<i;k++)
       {
           if(A[j]>A[k])
           {
               a=A[j];
               A[j]=A[k];
               A[k]=a;
           }
       }
    }

    for(j=0;j<i;j++)
        {if(A[j]<V[j])
          s=s+(V[j]-A[j]);
          else s=s+(A[j]-V[j]);
        }

    printf("%d",s);

	fclose(file);
	return 0;

}
