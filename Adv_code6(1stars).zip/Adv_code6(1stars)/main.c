
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int n,i=0,m=0,j,k,nr=0,ok=0,k1,j1,z;
   char c,A[1000][1000],line[10000];


   FILE *file;
   file=fopen("er.txt","r");


   if(file==NULL)
    {
        printf("Eroare la deschiderea fisierului.");
        return 1;
    }

   memset(A, '.', sizeof(A));

   while(fgets(line,sizeof(line),file))
   {
       n=strlen(line);
         for(j=0;j<n;j++)
            A[i][j]=line[j];
       i++;
   }

    for(k=0;k<i;k++)
        {for(j=0;j<n;j++)
            printf("%c",A[k][j]);
         printf("\n");
        }


    for(k=0;k<i;k++)
       for(j=0;j<n;j++)
         if(A[k][j]=='^')
            {k1=k;
            j1=j;
            }

    z=0;
    while((k1!=0 && j1!=0 && k1!=n-1 && j1!=i-1 ) && (k1<i && k1>=0 && j1<n && j1>=0 && k1<i && k1>=0 && j1<n && j1>=0 ))
            {while((A[k1-1][j1]=='.' || A[k1-1][j1]=='X') && k1>=0)
              {   if(A[k1-1][j1]=='X')
                     z++;
                     printf("\n\n");
                     printf("pentru pozitia %d\n",z);
                     for(k=0;k<i;k++)
                          {for(j=0;j<n;j++)
                              printf("%c",A[k][j]);
                           printf("\n");
                          }

                  A[k1-1][j1]='^';
                  A[k1][j1]='X';
                  k1--;

              }

             while((A[k1][j1+1]=='.' || A[k1][j1+1]=='X') && j1<n)
              {     if(A[k1][j1+1]=='X')
                      z++;
                      printf("\n\n");
                     printf("pentru pozitia %d\n",z);
                     for(k=0;k<i;k++)
                          {for(j=0;j<n;j++)
                              printf("%c",A[k][j]);
                           printf("\n");
                          }

                    A[k1][j1+1]='^';
                    A[k1][j1]='X';
                    j1++;
              }

              while((A[k1+1][j1]=='.' || A[k1+1][j1]=='X') && k1<i)
              {    if(A[k1+1][j1]=='X')
                     z++;
                     printf("\n\n");
                     printf("pentru pozitia %d\n",z);
                     for(k=0;k<i;k++)
                          {for(j=0;j<n;j++)
                              printf("%c",A[k][j]);
                           printf("\n");
                          }


                  A[k1+1][j1]='^';
                  A[k1][j1]='X';
                  k1++;
              }

              while((A[k1][j1-1]=='.' || A[k1][j1-1]=='X') && j1>=0)
              {   if(A[k1][j1-1]=='X')
                     z++;
                     printf("\n\n");
                     printf("pentru pozitia %d\n",z);
                     for(k=0;k<i;k++)
                          {for(j=0;j<n;j++)
                              printf("%c",A[k][j]);
                           printf("\n");
                          }


                  A[k1][j1-1]='^';
                  A[k1][j1]='X';
                  j1--;
              }

            }
            z++;

   //part 2


  printf("%d pozitii\n",z);

    printf("\n\n");
    for(k=0;k<i;k++)
       {for(j=0;j<n;j++)
           printf("%c",A[k][j]);
        printf("\n");
       }

    for(k=0;k<i;k++)
       {for(j=0;j<n;j++)
          if(A[k][j]=='X' )
            nr++;
       }
    printf("\n\n");
    printf("Paznicul viziteaza %d pozitii.",nr);
    fclose(file);
    return 0;
}
