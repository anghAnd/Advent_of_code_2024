#include <stdio.h>
#include <stdlib.h>

int main()
{
    int s=0,c1,c2,d;
    char c;


    FILE *file;
    file=fopen("input.txt","r");

     if(file==NULL)
    {
        printf("Eroare la deschiderea fisierului.\n");
        return 1;
    }

    while((c=fgetc(file))!=EOF)
    {
        if(c=='m')
            { //printf("%c",c);
              c=fgetc(file);
              if(c=='u')
             {   //printf("%c",c);
                 c=fgetc(file);
                 if(c=='l')
                 {   //printf("%c",c);
                     c=fgetc(file);
                     if(c=='(')
                     {   //printf("%c",c);
                         c=fgetc(file);
                         if(c>='0' && c<='9')
                           {  c1=c-'0';
                              c=fgetc(file);
                              while(c>='0' && c<='9')
                              {
                                  c1=c1*10+(c-'0');
                                  c=fgetc(file);
                              }
                              //printf("%d",c1);
                             if(c==',')
                             {   //printf("%c",c);
                                 c=fgetc(file);
                                 if(c>='0' && c<='9')
                                 {   c2=c-'0';
                                     c=fgetc(file);
                                     while(c>='0' && c<='9')
                                      {
                                        c2=c2*10+(c-'0');
                                        c=fgetc(file);
                                      }
                                     //printf("%d",c2);
                                     if(c==')')
                                     {   //printf("%c \n",c);
                                         d=c1*c2;
                                         printf("%d*%d=%d \n",c1,c2,d);
                                         s=s+d;
                                         printf("Total sum after multiplication: %d\n", s);
                                     }

                                 }
                             }
                           }
                     }
                 }
             }
            }
    }

    printf("\nThe result of multiplications is: %d",s);

    fclose(file);
    return 0;
}
