#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,j,V[100],nr=0,k,ok,m,l;
    char line[100];


    FILE *file;
    file=fopen("input.txt","r");

    if(file==NULL)
    {
        printf_s("Eroare la deschiderea fisierului.\n");
        return 1;
    }

    while(fgets(line,sizeof(line),file))
    {  char *ptr=line;
        i=0;
       while(sscanf(ptr,"%d", &V[i])==1)
       {
          i++;
          while(*ptr!=' ' && *ptr!='\0')
            ptr++;
          while(*ptr==' ')
            ptr++;

       }
       for(j=0;j<i;j++)
           printf("%d ",V[j]);
       printf("\n");


       k=1;//pp ca linia este ordonata crescator
       ok=1; //pp ca linia este ordonata descrescator

       m=0;
       l=0;
       for(j=0;j<i-1;j++)
           {
              if(V[j]>=V[j+1])
                 k=0;
              if(V[j]<=V[j+1])
                 ok=0;
           }
        if(k==1)
           {   m=1;
               for(j=0;j<i-1;j++)
               if(V[j+1]-V[j]<=0 || V[j+1]-V[j]>=4)
                   m=0;
           }
            else if(ok==1)
                   { l=1;
                     for(j=0;j<i-1;j++)
                      if(V[j]-V[j+1]<=0 || V[j]-V[j+1]>=4)
                            l=0;
                   }
        if(m==1 || l==1)
            nr++;
    }

    printf("%d",nr);


    return 0;
}
