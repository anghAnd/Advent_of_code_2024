#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int n,i=-1,m=-1,j,nr=0;
    char A[1000][1000],c,line[1000];

    FILE *file;
    file=fopen("input.txt","r");

    if(file==NULL)
    {
        printf("Eroare la deschiderea fisierului.");
        return 1;
    }

    while(fgets(line,sizeof(line),file))
    {   i++;
        n=strlen(line);
        if (line[n - 1] == '\n')  // Elimin� newline-ul
            line[n - 1] = '\0';
        for(j=0;j<n;j++)//numarul de coloane + parcurgerea liniei curente
            A[i][j]=line[j];
        m++;//numarul liniei
    }

   for(j=-1;j<=n;j++)
        {A[-1][j]='*';
         A[m+1][j]='*';
        }
    for(i=-1;i<=m+1;i++)
        {A[i][-1]='*';
         A[i][n]='*';
        }
    for(i=-1;i<=m+1;i++)
        {for(j=-1;j<=n;j++)
           printf("%c",A[i][j]);
         printf("\n");
        }

    for(i=0;i<=m;i++)
        for(j=0;j<n;j++)
           {   // XMAS scris pe verticala
               if(A[i][j]=='X')
                  if(A[i+1][j]=='M')
                    if(A[i+2][j]=='A')
                      if(A[i+3][j]=='S')
                          nr++;
                // SAMX scrie pe verticala
                if(A[i][j]=='S')
                    if(A[i+1][j]=='A')
                      if(A[i+2][j]=='M')
                        if(A[i+3][j]=='X')
                           nr++;
                // XMAS pe orizontala
                if(A[i][j]=='X')
                    if(A[i][j+1]=='M')
                       if(A[i][j+2]=='A')
                          if(A[i][j+3]=='S')
                            nr++;
                // SAMX pe orizontala
                if(A[i][j]=='S')
                    if(A[i][j+1]=='A')
                      if(A[i][j+2]=='M')
                         if(A[i][j+3]=='X')
                            nr++;
                // XMAS pe diagonala in stanga
                if(A[i][j]=='X')
                   if(A[i+1][j-1]=='M')
                       if(A[i+2][j-2]=='A')
                          if(A[i+3][j-3]=='S')
                            nr++;
                // SAMX pe diagonala in stanga
                if(A[i][j]=='S')
                    if(A[i+1][j-1]=='A')
                        if(A[i+2][j-2]=='M')
                           if(A[i+3][j-3]=='X')
                               nr++;
                // XMAS pe diagonala in dreapta
                if(A[i][j]=='X')
                     if(A[i+1][j+1]=='M')
                         if(A[i+2][j+2]=='A')
                             if(A[i+3][j+3]=='S')
                                nr++;
                // SAMX pe diagonala in dreapta
                if(A[i][j]=='S')
                     if(A[i+1][j+1]=='A')
                         if(A[i+2][j+2]=='M')
                            if(A[i+3][j+3]=='X')
                                 nr++;

            }
           printf("\nThe word XMAS appears %d times.",nr);
    fclose(file);
    return 0;
}
