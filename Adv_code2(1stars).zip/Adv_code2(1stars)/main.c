#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,j,V[100],nr=0,k,ok,m,l,ok1,k1,m1,l1,s,q,nr1=0,notc,notd,c,d;
    char line[100];
    int sir=-1;

    FILE *file;
    file=fopen("es.txt","r");

    if(file==NULL)
    {
        printf_s("Eroare la deschiderea fisierului.\n");
        return 1;
    }

    while(fgets(line,sizeof(line),file))
    {  notc=0;notd=0;
        char *ptr=line;
       sir++;
        i=0;
       while(sscanf(ptr,"%d", &V[i])==1)
       {
          i++;
          while(*ptr!=' ' && *ptr!='\0')
            ptr++;
          while(*ptr==' ')
            ptr++;

       }
       for(j=0;j<i;j++)
           printf("%d ",V[j]);
       printf("\n");


       k=1;//pp ca linia este ordonata crescator
       ok=1; //pp ca linia este ordonata descrescator



       m=0;
       l=0;
       for(j=0;j<i-1;j++)
           {
              if(V[j]>=V[j+1])
                 {k=0;
                  notc++; // de cate ori se abate de la regula si sunt descrescatoare
                  c=V[j];
                 }

              if(V[j]<=V[j+1])
                 {ok=0;
                  notd++; // de cate ori se abate de la regula si sunt crescatoare
                  d=V[j];
                 }

           }

        if(k==1) //daca e crescator
           {  m=1; //pp ca distanta este corecta
              for(j=0;j<i-1;j++)
                if(V[j+1]-V[j]<=0 || V[j+1]-V[j]>=4) // conditia din care iese ca nu e distata corecta
                  {m=0;
                  //part2
                   if(V[j+1]-V[j-1]>0 || V[j+1]-V[j-1]<4)
                     {  for(q=j;q<i-1;q++)
                           V[q]=V[q+1];
                        i--;

                     }
                     else if(V[j+2]-V[j]>0 || V[j+2]-V[j]<4)
                     {
                         for(q=j+1;q<i-1;q++)
                             V[q]=V[q+1];
                          i--;
                     }

                  }
                if(m==0)
                { m1=1;
                for(j=0;j<i-1;j++)
                    if(V[j+1]-V[j]<=0 || V[j+1]-V[j]>=4) // conditia din care iese ca nu e distata corecta
                       m1=0;

                }
           }

            else if(ok==1)
                   { l=1;
                     for(j=0;j<i-1;j++)
                      if(V[j]-V[j+1]<=0 || V[j]-V[j+1]>=4)
                            {l=0;
                            //part 2
                              if(V[j+1]-V[j-1]>0 || V[j+1]-V[j-1]<4)
                                  {  for(q=j;q<i-1;q++)
                                         {V[q]=V[q+1];
                                           i--;
                                         }

                                   }
                               else if(V[j+2]-V[j]>0 || V[j+2]-V[j]<4)
                                        {
                                          for(q=j+1;q<i-1;q++)
                                            {  V[q]=V[q+1];
                                               i--;
                                            }
                                        }

                                 }
                if(l==0)
                { l1=1;
                 for(j=0;j<i-1;j++)
                    if(V[j+1]-V[j]<=0 || V[j+1]-V[j]>=4) // conditia din care iese ca nu e distata corecta
                       l1=0;

                }

                 }
       if(k1==1)
       { m1=1; //pp ca distanta este corecta
            for(j=0;j<i-1;j++)
                if(V[j+1]-V[j]<=0 || V[j+1]-V[j]>=4) // conditia din care iese ca nu e distata corecta
                  m1=0;

       }
       if(ok1==1)
        { l1=1;
          for(j=0;j<i-1;j++)
            if(V[j]-V[j+1]<=0 || V[j]-V[j+1]>=4)
                l1=0;
        }

        if(ok==0 && k==0)
        {
            if(notc==1)
                k1=1;
            if(notd==1)
                ok1=1;
        }

         if(k1==1) //daca e crescator
           {  m1=1; //pp ca distanta este corecta
              for(j=0;j<i-1;j++)
                if(V[j]!=c || V[j+1]!=c)
                  if(V[j+1]-V[j]<=0 || V[j+1]-V[j]>=4) // conditia din care iese ca nu e distata corecta
                     m1=0;
           }
           else if(ok1==1)
                   { l1=1;
                     for(j=0;j<i-1;j++)
                        if(V[j]!=d || V[j+1]!=d)
                          if(V[j]-V[j+1]<=0 || V[j]-V[j+1]>=4)
                            l1=0;
                   }



        if(m==1 || l==1)
            {nr++;
             printf("%d e sigur\n",sir);
            }
        if((m1==1 || l1==1) && (m==0 && l==0))
            {nr1++;
             printf("\n %d e sigur dupa modificare\n",sir);
            }
         if(m==0 && l==0 && m1==0 && l1==0 )
            printf("%d nu este sigur \n",sir);


    }
    printf("Sigure de la inceput: %d.\n",nr);
    printf("Sigure dupa eliminarea unui numar: %d\n",nr1);
    printf("In total sunt %d sigure.",nr+nr1);
    fclose(file);
    return 0;
}
